import axios from 'axios';
// THIS IS THE STEP 1 TO CHECK THE API
export const checkApi=async(req,res)=>{
    try {
        res.status(200).send({
            success:"true"
        })
    } catch (error) {
        res.status(500).json({
            error:"An error has been occured!"
        })
    }
    
}

// FETCHING AND SENDING POSTS BASED ON THE TAGS
export const getPosts=async(req,res)=>{
   
   const {tags:tags}=req.params;
   try {
    const response= await axios.get(`http://hatchways.io/api/assessment/blog/posts?tag=${tags}`)
    .then(request => {
        let data = request.data.posts;
        
        res.status(200).send(data);
      })
      .catch(error=>{
          res.status(400).send({
              error:"tag param is mandatory"
          })
          console.log(error)
      })
       
   } catch (error) {
        res.status(500).json({message:error.message})
       
   }
}