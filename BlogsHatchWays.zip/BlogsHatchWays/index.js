import express from "express";
import bodyParser  from "body-parser";
import cors from 'cors';
import dotenv from 'dotenv';
import blogs from './routes/blogs.js'
import getPosts from './routes/blogs.js'
import apicache from 'apicache'
const app= express();

app.use(cors());
app.use(express.json({limit:'100mb'}))
app.use(bodyParser.json({limit:"100mb",extended:true}))
app.use(bodyParser.urlencoded({limit:"100mb",extended:true}))
dotenv.config();

//initializing cache middleware
const cache= apicache.middleware;


const PORT= process.env.PORT||3000;


//API CHECK MAIN ROUTE
app.use('/api',cache("60 minutes"),blogs)

//GET POSTS MAIN ROUTE
app.use('/api',cache("60 minutes"),getPosts)


app.use('/',(req,res)=>{
    res.send("Hello from Hatchways API")
})

app.listen(PORT,()=>{
    console.log(`Listening on ${PORT}`)

})
