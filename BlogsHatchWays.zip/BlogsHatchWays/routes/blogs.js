import express from 'express'
import {checkApi,getPosts} from '../controllers/blogs.js'

 const router = express.Router();
//CHECK API SUBROUTE
 router.get('/ping',checkApi)
 
// FETCH POSTS SUBROUTE
 router.get('/posts/:tags',getPosts)

 export default router;